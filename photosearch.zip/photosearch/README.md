# PhotoSearch

An internal media search dashboard for a school's Google Shared Drive. Index thousands of photos and videos, then find them by what's *in* them ("kids painting", "sports day") as well as by filename, folder, and tags — with bulk download, inline rename, and a fast tagging workflow.

## Architecture

```
frontend (React + Tailwind, Vite)
   │  /api proxy
backend (FastAPI) ──────────────► Google Drive API (metadata, thumbnails, rename, download)
   │            │
   │            ├──► PostgreSQL + pgvector (file index, tags, embeddings)
   │            └──► Redis (Celery broker)
worker + beat (Celery) ─────────► clip-service (self-hosted open_clip, ViT-B-32)
```

- **Indexing** is a scheduled background job (Celery beat), not real-time. Each run walks active folders a few pages at a time, with sleeps between Drive calls, then saves its position and resumes next run — so it stays under API quotas on cheap infrastructure.
- **Embeddings** are computed from Drive's own ~224px thumbnails (CLIP's native input size — the original file is never downloaded for this), sent to the self-hosted open_clip service, and cached permanently in pgvector. A file is only re-embedded if its md5 checksum changes.
- **Videos** are indexed by filename/metadata/tags only in v1 (no embeddings).
- **Search** blends CLIP cosine similarity, trigram similarity on filename + folder path, and tag matches into one ranked result set. If the CLIP service is down, search degrades gracefully to text-only.

## Setup

1. **Google Cloud project**
   - Enable the **Google Drive API**.
   - Create an **OAuth client (Web application)** with redirect URI `http://localhost:8000/auth/callback`.
   - Because this app handles photos of minors, keep the OAuth consent screen in *Internal* mode (Workspace) or restrict test users — do not publish it.

2. **Configure**
   ```bash
   cp .env.example .env   # fill in GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET
   ```

3. **Run**
   ```bash
   docker compose up --build
   ```
   First start downloads the CLIP weights (~600MB, cached in a volume).

4. **Use**
   - Open http://localhost:5173 → **Connect Google Drive**.
   - Open **Indexing** → browse Drive → pick one folder to start (e.g. one school year). Add more folders incrementally later.
   - Watch progress in the Indexing panel; search works immediately on metadata, and visual search improves as embeddings fill in.

## Cost controls (and where to tune them)

| Control | Where |
|---|---|
| Self-hosted CLIP, no per-call fees | `clip-service/` |
| Embed 224px thumbnails, never originals | `EMBED_THUMB_SIZE`, `tasks.embed_file` |
| Permanent embedding cache, re-embed only on md5 change | `files.embedded_md5` |
| Scoped + incremental folder indexing | Indexing panel / `indexed_folders` |
| Batched, rate-limited jobs | `INDEX_PAGES_PER_RUN`, `INDEX_SLEEP_BETWEEN_PAGES`, `EMBED_RATE_LIMIT` |
| Skip video embedding in v1 | `tasks._upsert_file` |
| Lazy-loaded thumbnails | `Grid.jsx` IntersectionObserver |

## Data note

This app handles photos of minors. It exposes nothing beyond the authenticated account's existing Drive permissions: no public links are created, thumbnails are served via authenticated Drive URLs, and there is no sharing or publishing surface. Run it on a private network or behind your school's SSO/VPN, and keep the OAuth app internal.

## Out of scope for v1

Face recognition, multi-tenant support, granular permissions, and image editing — by design.
