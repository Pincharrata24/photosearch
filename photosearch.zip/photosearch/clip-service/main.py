"""Self-hosted open_clip embedding service (no per-call API fees).

ViT-B-32 on CPU is fine for thumbnails: input images are already ~224px,
so preprocessing is cheap and embedding takes ~50ms/image.
"""
import io

import open_clip
import torch
from fastapi import FastAPI, UploadFile
from PIL import Image
from pydantic import BaseModel

MODEL_NAME = "ViT-B-32"
PRETRAINED = "laion2b_s34b_b79k"

app = FastAPI(title="CLIP service")

model, _, preprocess = open_clip.create_model_and_transforms(MODEL_NAME, pretrained=PRETRAINED)
tokenizer = open_clip.get_tokenizer(MODEL_NAME)
model.eval()


def _normalize(t: torch.Tensor) -> list[float]:
    t = t / t.norm(dim=-1, keepdim=True)
    return t.squeeze(0).tolist()


@app.post("/embed_image")
async def embed_image(file: UploadFile):
    img = Image.open(io.BytesIO(await file.read())).convert("RGB")
    with torch.no_grad():
        feats = model.encode_image(preprocess(img).unsqueeze(0))
    return {"embedding": _normalize(feats)}


class TextBody(BaseModel):
    text: str


@app.post("/embed_text")
def embed_text(body: TextBody):
    with torch.no_grad():
        feats = model.encode_text(tokenizer([body.text]))
    return {"embedding": _normalize(feats)}


@app.get("/health")
def health():
    return {"ok": True, "model": MODEL_NAME}
