from datetime import datetime

from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    BigInteger, Boolean, Column, DateTime, ForeignKey, Integer, String, Table, Text,
)
from sqlalchemy.orm import relationship

from .config import settings
from .db import Base

file_tags = Table(
    "file_tags",
    Base.metadata,
    Column("file_id", String, ForeignKey("files.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", Integer, ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
)


class File(Base):
    __tablename__ = "files"

    id = Column(String, primary_key=True)          # Drive file ID
    name = Column(String, nullable=False, index=True)
    mime_type = Column(String, nullable=False, index=True)
    folder_id = Column(String, index=True)
    folder_path = Column(Text, default="")
    size = Column(BigInteger)
    created_time = Column(DateTime, index=True)
    modified_time = Column(DateTime, index=True)
    thumbnail_link = Column(Text)
    web_view_link = Column(Text)
    md5 = Column(String)                            # change detection: re-embed only if this changes
    is_video = Column(Boolean, default=False, index=True)

    embedding = Column(Vector(settings.EMBEDDING_DIM), nullable=True)
    embedded_md5 = Column(String)                   # md5 the current embedding was computed from
    embed_error = Column(Text)

    indexed_at = Column(DateTime, default=datetime.utcnow)
    tags = relationship("Tag", secondary=file_tags, back_populates="files", lazy="selectin")


class Tag(Base):
    __tablename__ = "tags"

    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False, index=True)
    files = relationship("File", secondary=file_tags, back_populates="tags")


class IndexedFolder(Base):
    __tablename__ = "indexed_folders"

    id = Column(String, primary_key=True)           # Drive folder ID
    name = Column(String, nullable=False)
    path = Column(Text, default="")
    active = Column(Boolean, default=True)
    # incremental sync state
    page_token = Column(Text)                       # resume point inside a full walk
    pending_subfolders = Column(Text)               # JSON list of subfolder IDs still to walk
    total_estimate = Column(Integer, default=0)
    indexed_count = Column(Integer, default=0)
    status = Column(String, default="queued")       # queued | indexing | done | error
    last_synced_at = Column(DateTime)
    error = Column(Text)


class Credential(Base):
    __tablename__ = "credentials"

    id = Column(Integer, primary_key=True)
    account_email = Column(String)
    token_json = Column(Text, nullable=False)       # google Credentials.to_json()
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
