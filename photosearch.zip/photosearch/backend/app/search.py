"""Blended ranking: CLIP visual similarity + filename + tags + folder path."""
import httpx
from sqlalchemy import text

from .config import settings

W_CLIP = 0.55
W_TEXT = 0.30
W_TAG = 0.15
CLIP_FLOOR = 0.18  # cosine sim below this is noise for CLIP ViT-B-32


def embed_query(q: str) -> list[float] | None:
    try:
        r = httpx.post(f"{settings.CLIP_URL}/embed_text", json={"text": q}, timeout=10)
        r.raise_for_status()
        return r.json()["embedding"]
    except httpx.HTTPError:
        return None  # degrade gracefully to text-only search


def search_files(db, q: str | None, filters: dict, limit: int, offset: int):
    params: dict = {"limit": limit, "offset": offset}
    where = ["1=1"]

    if filters.get("type") == "photo":
        where.append("f.is_video = false")
    elif filters.get("type") == "video":
        where.append("f.is_video = true")
    if filters.get("folder"):
        where.append("f.folder_path ILIKE :folder")
        params["folder"] = f"%{filters['folder']}%"
    if filters.get("date_from"):
        where.append("f.created_time >= :date_from")
        params["date_from"] = filters["date_from"]
    if filters.get("date_to"):
        where.append("f.created_time <= :date_to")
        params["date_to"] = filters["date_to"]
    if filters.get("tagged") == "tagged":
        where.append("EXISTS (SELECT 1 FROM file_tags ft WHERE ft.file_id = f.id)")
    elif filters.get("tagged") == "untagged":
        where.append("NOT EXISTS (SELECT 1 FROM file_tags ft WHERE ft.file_id = f.id)")
    if filters.get("tag"):
        where.append(
            "EXISTS (SELECT 1 FROM file_tags ft JOIN tags t ON t.id = ft.tag_id "
            "WHERE ft.file_id = f.id AND t.name = :tag)"
        )
        params["tag"] = filters["tag"]

    if q:
        params["q"] = q
        qvec = embed_query(q)
        if qvec is not None:
            params["qvec"] = str(qvec)
            clip_expr = (
                "GREATEST(0, CASE WHEN f.embedding IS NULL THEN 0 "
                "ELSE 1 - (f.embedding <=> CAST(:qvec AS vector)) END - "
                f"{CLIP_FLOOR}) / (1 - {CLIP_FLOOR})"
            )
        else:
            clip_expr = "0"
        score = f"""
            ({W_CLIP} * ({clip_expr})
           + {W_TEXT} * GREATEST(similarity(f.name, :q), similarity(f.folder_path, :q) * 0.8)
           + {W_TAG}  * COALESCE((
                SELECT MAX(similarity(t.name, :q))
                FROM file_tags ft JOIN tags t ON t.id = ft.tag_id
                WHERE ft.file_id = f.id), 0))
        """
        where.append(f"({score}) > 0.06")
        order = f"({score}) DESC"
    else:
        score = "0"
        order = "f.created_time DESC NULLS LAST"

    sql = text(f"""
        SELECT f.id, f.name, f.mime_type, f.folder_path, f.size,
               f.created_time, f.modified_time, f.thumbnail_link,
               f.web_view_link, f.is_video, ({score}) AS score,
               COALESCE((
                   SELECT array_agg(t.name ORDER BY t.name)
                   FROM file_tags ft JOIN tags t ON t.id = ft.tag_id
                   WHERE ft.file_id = f.id), '{{}}') AS tags
        FROM files f
        WHERE {' AND '.join(where)}
        ORDER BY {order}
        LIMIT :limit OFFSET :offset
    """)
    rows = db.execute(sql, params).mappings().all()
    return [dict(r) for r in rows]
