import os


class Settings:
    DATABASE_URL = os.getenv(
        "DATABASE_URL", "postgresql+psycopg2://photosearch:photosearch@db:5432/photosearch"
    )
    REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
    CLIP_URL = os.getenv("CLIP_URL", "http://clip:8001")

    GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "")
    GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "")
    OAUTH_REDIRECT_URI = os.getenv("OAUTH_REDIRECT_URI", "http://localhost:8000/auth/callback")
    FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5173")
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")

    # Drive scopes: read everything, write only file metadata (rename)
    GOOGLE_SCOPES = [
        "https://www.googleapis.com/auth/drive",
    ]

    # Cost / quota controls
    INDEX_PAGE_SIZE = int(os.getenv("INDEX_PAGE_SIZE", "200"))       # files per Drive list call
    INDEX_PAGES_PER_RUN = int(os.getenv("INDEX_PAGES_PER_RUN", "10"))  # batch size per scheduled run
    INDEX_SLEEP_BETWEEN_PAGES = float(os.getenv("INDEX_SLEEP_BETWEEN_PAGES", "1.0"))
    EMBED_RATE_LIMIT = os.getenv("EMBED_RATE_LIMIT", "120/m")        # celery rate limit per worker
    SYNC_INTERVAL_MINUTES = int(os.getenv("SYNC_INTERVAL_MINUTES", "30"))
    EMBED_THUMB_SIZE = int(os.getenv("EMBED_THUMB_SIZE", "224"))     # CLIP native input

    EMBEDDING_DIM = 512  # ViT-B-32


settings = Settings()
