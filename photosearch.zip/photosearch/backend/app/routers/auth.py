from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from ..config import settings
from ..db import get_db
from ..drive import oauth_flow, save_credentials
from ..models import Credential

router = APIRouter(prefix="/auth", tags=["auth"])


@router.get("/login")
def login():
    flow = oauth_flow()
    url, _state = flow.authorization_url(
        access_type="offline", include_granted_scopes="true", prompt="consent"
    )
    return RedirectResponse(url)


@router.get("/callback")
def callback(request: Request):
    flow = oauth_flow()
    flow.fetch_token(authorization_response=str(request.url))
    creds = flow.credentials
    email = None
    try:
        from googleapiclient.discovery import build

        about = build("drive", "v3", credentials=creds, cache_discovery=False) \
            .about().get(fields="user(emailAddress)").execute()
        email = about["user"]["emailAddress"]
    except Exception:  # noqa: BLE001
        pass
    save_credentials(creds, email)
    return RedirectResponse(settings.FRONTEND_URL)


@router.get("/status")
def status(db: Session = Depends(get_db)):
    row = db.query(Credential).first()
    return {"connected": row is not None, "email": row.account_email if row else None}
