import io
import zipfile

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from ..db import get_db
from ..drive import download_file, drive_service, rename_file
from ..models import File, Tag
from ..search import search_files

router = APIRouter(tags=["files"])


@router.get("/search")
def search(
    q: str | None = None,
    type: str | None = Query(None, pattern="^(photo|video)$"),
    folder: str | None = None,
    tag: str | None = None,
    tagged: str | None = Query(None, pattern="^(tagged|untagged)$"),
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int = Query(60, le=200),
    offset: int = 0,
    db: Session = Depends(get_db),
):
    filters = {
        "type": type, "folder": folder, "tag": tag, "tagged": tagged,
        "date_from": date_from, "date_to": date_to,
    }
    return search_files(db, (q or "").strip() or None, filters, limit, offset)


@router.get("/files/recent")
def recent(limit: int = 40, db: Session = Depends(get_db)):
    """Empty-state content: recently added or recently tagged photos."""
    return search_files(db, None, {}, limit, 0)


class RenameBody(BaseModel):
    name: str


@router.patch("/files/{file_id}/rename")
def rename(file_id: str, body: RenameBody, db: Session = Depends(get_db)):
    f = db.get(File, file_id)
    if not f:
        raise HTTPException(404, "File not found")
    name = body.name.strip()
    if not name:
        raise HTTPException(422, "Name cannot be empty")
    rename_file(drive_service(), file_id, name)  # sync to Drive
    f.name = name
    db.commit()
    return {"id": file_id, "name": name}


class TagsBody(BaseModel):
    tags: list[str]


def _get_or_create_tags(db: Session, names: list[str]) -> list[Tag]:
    out = []
    for raw in names:
        name = " ".join(raw.split()).strip()
        if not name:
            continue
        tag = db.query(Tag).filter(Tag.name.ilike(name)).first()
        if not tag:
            tag = Tag(name=name)
            db.add(tag)
            db.flush()
        out.append(tag)
    return out


@router.post("/files/{file_id}/tags")
def add_tags(file_id: str, body: TagsBody, db: Session = Depends(get_db)):
    f = db.get(File, file_id)
    if not f:
        raise HTTPException(404, "File not found")
    for tag in _get_or_create_tags(db, body.tags):
        if tag not in f.tags:
            f.tags.append(tag)
    db.commit()
    return {"id": file_id, "tags": sorted(t.name for t in f.tags)}


@router.delete("/files/{file_id}/tags/{tag_name}")
def remove_tag(file_id: str, tag_name: str, db: Session = Depends(get_db)):
    f = db.get(File, file_id)
    if not f:
        raise HTTPException(404, "File not found")
    f.tags = [t for t in f.tags if t.name.lower() != tag_name.lower()]
    db.commit()
    return {"id": file_id, "tags": sorted(t.name for t in f.tags)}


class BulkTagBody(BaseModel):
    file_ids: list[str]
    tags: list[str]


@router.post("/tags/bulk")
def bulk_tag(body: BulkTagBody, db: Session = Depends(get_db)):
    tags = _get_or_create_tags(db, body.tags)
    files = db.query(File).filter(File.id.in_(body.file_ids)).all()
    for f in files:
        for tag in tags:
            if tag not in f.tags:
                f.tags.append(tag)
    db.commit()
    return {"updated": len(files)}


@router.get("/tags")
def list_tags(prefix: str | None = None, db: Session = Depends(get_db)):
    q = db.query(Tag).order_by(Tag.name)
    if prefix:
        q = q.filter(Tag.name.ilike(f"{prefix}%"))
    return [t.name for t in q.limit(25).all()]


class DownloadBody(BaseModel):
    file_ids: list[str]


@router.post("/download")
def bulk_download(body: DownloadBody, db: Session = Depends(get_db)):
    files = db.query(File).filter(File.id.in_(body.file_ids)).all()
    if not files:
        raise HTTPException(404, "No files found")
    service = drive_service()

    def stream():
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            seen: set[str] = set()
            for f in files:
                name = f.name
                i = 1
                while name in seen:
                    stem, dot, ext = f.name.rpartition(".")
                    name = f"{stem or ext} ({i}){dot}{ext if stem else ''}"
                    i += 1
                seen.add(name)
                try:
                    zf.writestr(name, download_file(service, f.id))
                except Exception:  # noqa: BLE001
                    zf.writestr(f"FAILED_{name}.txt", "Download from Drive failed.")
                # flush what we have so the client sees progress
                buf.seek(0)
                chunk = buf.read()
                buf.seek(0)
                buf.truncate()
                yield chunk
        buf.seek(0)
        yield buf.read()

    return StreamingResponse(
        stream(),
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="photosearch.zip"'},
    )
