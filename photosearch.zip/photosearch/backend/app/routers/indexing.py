from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..db import get_db
from ..drive import drive_service, list_folders
from ..models import File, IndexedFolder
from ..tasks import index_folder_batch

router = APIRouter(prefix="/index", tags=["indexing"])


@router.get("/browse")
def browse(parent: str | None = None):
    """Browse Drive folders so the user can scope indexing to a subset first."""
    return list_folders(drive_service(), parent)


class AddFoldersBody(BaseModel):
    folders: list[dict]  # [{id, name}]


@router.post("/folders")
def add_folders(body: AddFoldersBody, db: Session = Depends(get_db)):
    for item in body.folders:
        row = db.get(IndexedFolder, item["id"])
        if not row:
            row = IndexedFolder(id=item["id"], name=item["name"], path=item["name"])
            db.add(row)
        row.active = True
        row.status = "queued"
        db.commit()
        index_folder_batch.delay(item["id"])  # kick off immediately, then beat resumes it
    return {"ok": True}


@router.delete("/folders/{folder_id}")
def remove_folder(folder_id: str, db: Session = Depends(get_db)):
    row = db.get(IndexedFolder, folder_id)
    if row:
        row.active = False
        db.commit()
    return {"ok": True}


@router.get("/status")
def status(db: Session = Depends(get_db)):
    folders = db.query(IndexedFolder).filter(IndexedFolder.active.is_(True)).all()
    total_files = db.query(func.count(File.id)).scalar() or 0
    embedded = db.query(func.count(File.id)).filter(File.embedding.isnot(None)).scalar() or 0
    embeddable = db.query(func.count(File.id)).filter(File.is_video.is_(False)).scalar() or 0
    return {
        "folders": [
            {
                "id": f.id, "name": f.name, "status": f.status,
                "indexed_count": f.indexed_count or 0,
                "last_synced_at": f.last_synced_at.isoformat() if f.last_synced_at else None,
                "error": f.error,
            }
            for f in folders
        ],
        "total_files": total_files,
        "embedded": embedded,
        "embeddable": embeddable,
    }
