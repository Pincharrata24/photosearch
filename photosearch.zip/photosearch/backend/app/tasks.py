"""Background jobs.

Cost-control design:
- Indexing walks folders a few pages at a time per scheduled run, with a sleep
  between Drive list calls, so it stays well under API quotas on cheap infra.
- Embeddings are computed from Drive's own ~224px thumbnails (never the
  original file), sent to the self-hosted open_clip service, and cached
  permanently in pgvector. A file is only re-embedded when its md5 changes.
- Videos are indexed by metadata only (no embedding) in v1.
"""
import json
import re
import time
from datetime import datetime

import httpx

from .celery_app import celery_app
from .config import settings
from .db import SessionLocal
from .drive import drive_service, list_children
from .models import File, IndexedFolder

IMAGE_RE = re.compile(r"^image/")
VIDEO_RE = re.compile(r"^video/")
FOLDER_MIME = "application/vnd.google-apps.folder"


def _parse_dt(value):
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)


@celery_app.task
def sync_all_folders():
    db = SessionLocal()
    try:
        folders = db.query(IndexedFolder).filter(IndexedFolder.active.is_(True)).all()
        for f in folders:
            if f.status != "done" or True:  # periodic re-walk picks up new files
                index_folder_batch.delay(f.id)
    finally:
        db.close()


@celery_app.task
def index_folder_batch(root_folder_id: str):
    """Process up to INDEX_PAGES_PER_RUN Drive pages for one indexed root,
    then stop and persist its position. The next scheduled run resumes."""
    db = SessionLocal()
    try:
        root = db.get(IndexedFolder, root_folder_id)
        if not root or not root.active:
            return
        service = drive_service()

        pending = json.loads(root.pending_subfolders or "[]")
        if root.status in ("queued", "done", "error"):
            # (re)start a walk from the root
            pending = [{"id": root.id, "path": root.path or root.name}]
            root.page_token = None
            root.status = "indexing"
            root.error = None
        db.commit()

        pages_done = 0
        while pending and pages_done < settings.INDEX_PAGES_PER_RUN:
            current = pending[0]
            resp = list_children(
                service, current["id"], root.page_token, settings.INDEX_PAGE_SIZE
            )
            for item in resp.get("files", []):
                mime = item.get("mimeType", "")
                if mime == FOLDER_MIME:
                    pending.append({
                        "id": item["id"],
                        "path": f"{current['path']}/{item['name']}",
                    })
                    continue
                is_image = bool(IMAGE_RE.match(mime))
                is_video = bool(VIDEO_RE.match(mime))
                if not (is_image or is_video):
                    continue
                _upsert_file(db, item, current, is_video)
                root.indexed_count = (root.indexed_count or 0) + 1

            root.page_token = resp.get("nextPageToken")
            if not root.page_token:
                pending.pop(0)
            root.pending_subfolders = json.dumps(pending)
            db.commit()
            pages_done += 1
            time.sleep(settings.INDEX_SLEEP_BETWEEN_PAGES)

        if not pending:
            root.status = "done"
            root.page_token = None
            root.pending_subfolders = None
            root.last_synced_at = datetime.utcnow()
        db.commit()
    except Exception as exc:  # noqa: BLE001
        db.rollback()
        root = db.get(IndexedFolder, root_folder_id)
        if root:
            root.status = "error"
            root.error = str(exc)[:2000]
            db.commit()
        raise
    finally:
        db.close()


def _upsert_file(db, item, current_folder, is_video):
    f = db.get(File, item["id"])
    if not f:
        f = File(id=item["id"])
        db.add(f)
    f.name = item.get("name", "")
    f.mime_type = item.get("mimeType", "")
    f.folder_id = current_folder["id"]
    f.folder_path = current_folder["path"]
    f.size = int(item.get("size") or 0)
    f.created_time = _parse_dt(item.get("createdTime"))
    f.modified_time = _parse_dt(item.get("modifiedTime"))
    f.thumbnail_link = item.get("thumbnailLink")
    f.web_view_link = item.get("webViewLink")
    f.md5 = item.get("md5Checksum")
    f.is_video = is_video
    f.indexed_at = datetime.utcnow()
    db.flush()
    # Images only, and only if content changed since last embedding (cache forever)
    if not is_video and f.embedded_md5 != f.md5:
        embed_file.delay(f.id)


@celery_app.task(rate_limit=settings.EMBED_RATE_LIMIT, max_retries=3, default_retry_delay=60, bind=True)
def embed_file(self, file_id: str):
    """Embed one image from a small thumbnail via the self-hosted CLIP service."""
    db = SessionLocal()
    try:
        f = db.get(File, file_id)
        if not f or f.is_video or (f.embedding is not None and f.embedded_md5 == f.md5):
            return
        if not f.thumbnail_link:
            f.embed_error = "no thumbnail available"
            db.commit()
            return

        # Drive thumbnail links accept a size suffix; request CLIP's native 224px.
        thumb_url = re.sub(r"=s\d+$", "", f.thumbnail_link) + f"=s{settings.EMBED_THUMB_SIZE}"
        from .drive import load_credentials

        creds = load_credentials()
        headers = {"Authorization": f"Bearer {creds.token}"} if creds else {}
        img = httpx.get(thumb_url, headers=headers, follow_redirects=True, timeout=30)
        img.raise_for_status()

        resp = httpx.post(
            f"{settings.CLIP_URL}/embed_image",
            files={"file": ("thumb.jpg", img.content, "image/jpeg")},
            timeout=60,
        )
        resp.raise_for_status()
        f.embedding = resp.json()["embedding"]
        f.embedded_md5 = f.md5
        f.embed_error = None
        db.commit()
    except Exception as exc:  # noqa: BLE001
        db.rollback()
        f = db.get(File, file_id)
        if f:
            f.embed_error = str(exc)[:2000]
            db.commit()
        raise self.retry(exc=exc)
    finally:
        db.close()
