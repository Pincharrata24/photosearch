from celery import Celery

from .config import settings

celery_app = Celery("photosearch", broker=settings.REDIS_URL, backend=settings.REDIS_URL)

celery_app.conf.update(
    task_default_queue="default",
    worker_prefetch_multiplier=1,
    beat_schedule={
        # Scheduled, not real-time: walk active folders in small batches.
        "sync-drive": {
            "task": "app.tasks.sync_all_folders",
            "schedule": settings.SYNC_INTERVAL_MINUTES * 60,
        },
    },
)

celery_app.autodiscover_tasks(["app"])
