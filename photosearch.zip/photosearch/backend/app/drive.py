"""Google OAuth and Drive API helpers.

Single-admin model: one stored credential, refreshed automatically.
"""
import json

from google.auth.transport.requests import Request as GoogleRequest
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build

from .config import settings
from .db import SessionLocal
from .models import Credential


def oauth_flow(state: str | None = None) -> Flow:
    return Flow.from_client_config(
        {
            "web": {
                "client_id": settings.GOOGLE_CLIENT_ID,
                "client_secret": settings.GOOGLE_CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
            }
        },
        scopes=settings.GOOGLE_SCOPES,
        redirect_uri=settings.OAUTH_REDIRECT_URI,
        state=state,
    )


def save_credentials(creds: Credentials, email: str | None = None):
    db = SessionLocal()
    try:
        row = db.query(Credential).first()
        if not row:
            row = Credential()
            db.add(row)
        row.token_json = creds.to_json()
        if email:
            row.account_email = email
        db.commit()
    finally:
        db.close()


def load_credentials() -> Credentials | None:
    db = SessionLocal()
    try:
        row = db.query(Credential).first()
        if not row:
            return None
        info = json.loads(row.token_json)
        creds = Credentials.from_authorized_user_info(info, settings.GOOGLE_SCOPES)
        if creds.expired and creds.refresh_token:
            creds.refresh(GoogleRequest())
            row.token_json = creds.to_json()
            db.commit()
        return creds
    finally:
        db.close()


def drive_service():
    creds = load_credentials()
    if not creds:
        raise RuntimeError("Google Drive is not connected yet.")
    return build("drive", "v3", credentials=creds, cache_discovery=False)


FILE_FIELDS = (
    "id, name, mimeType, parents, size, createdTime, modifiedTime, "
    "thumbnailLink, webViewLink, md5Checksum"
)


def list_children(service, folder_id: str, page_token: str | None, page_size: int):
    return service.files().list(
        q=f"'{folder_id}' in parents and trashed = false",
        fields=f"nextPageToken, files({FILE_FIELDS})",
        pageSize=page_size,
        pageToken=page_token,
        supportsAllDrives=True,
        includeItemsFromAllDrives=True,
    ).execute()


def list_folders(service, parent_id: str | None = None):
    q = "mimeType = 'application/vnd.google-apps.folder' and trashed = false"
    q += f" and '{parent_id or 'root'}' in parents"
    return service.files().list(
        q=q,
        fields="files(id, name)",
        pageSize=200,
        orderBy="name",
        supportsAllDrives=True,
        includeItemsFromAllDrives=True,
    ).execute().get("files", [])


def rename_file(service, file_id: str, new_name: str):
    return service.files().update(
        fileId=file_id, body={"name": new_name}, supportsAllDrives=True
    ).execute()


def download_file(service, file_id: str) -> bytes:
    return service.files().get_media(fileId=file_id, supportsAllDrives=True).execute()
