import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
    proxy: { '/api': { target: process.env.API_URL || 'http://localhost:8000', rewrite: p => p.replace(/^\/api/, '') } },
  },
})
