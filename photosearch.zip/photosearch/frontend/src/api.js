const BASE = '/api'

async function req(path, opts = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  })
  if (!res.ok) throw new Error((await res.text()) || res.statusText)
  return res.headers.get('content-type')?.includes('json') ? res.json() : res
}

export const api = {
  authStatus: () => req('/auth/status'),
  loginUrl: `${BASE}/auth/login`,

  search: (params) => req(`/search?${new URLSearchParams(clean(params))}`),
  recent: () => req('/files/recent'),

  rename: (id, name) =>
    req(`/files/${id}/rename`, { method: 'PATCH', body: JSON.stringify({ name }) }),

  addTags: (id, tags) =>
    req(`/files/${id}/tags`, { method: 'POST', body: JSON.stringify({ tags }) }),
  removeTag: (id, tag) =>
    req(`/files/${id}/tags/${encodeURIComponent(tag)}`, { method: 'DELETE' }),
  bulkTag: (file_ids, tags) =>
    req('/tags/bulk', { method: 'POST', body: JSON.stringify({ file_ids, tags }) }),
  tagSuggest: (prefix) => req(`/tags?${new URLSearchParams(clean({ prefix }))}`),

  indexStatus: () => req('/index/status'),
  browseFolders: (parent) => req(`/index/browse?${new URLSearchParams(clean({ parent }))}`),
  addFolders: (folders) =>
    req('/index/folders', { method: 'POST', body: JSON.stringify({ folders }) }),

  async download(file_ids, onDone) {
    const res = await fetch(`${BASE}/download`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ file_ids }),
    })
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = Object.assign(document.createElement('a'), { href: url, download: 'photosearch.zip' })
    a.click()
    URL.revokeObjectURL(url)
    onDone?.()
  },
}

function clean(obj) {
  return Object.fromEntries(Object.entries(obj).filter(([, v]) => v != null && v !== ''))
}

export function useDebounced(fn, ms = 250) {
  let t
  return (...args) => {
    clearTimeout(t)
    t = setTimeout(() => fn(...args), ms)
  }
}
