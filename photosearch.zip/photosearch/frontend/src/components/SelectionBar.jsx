import { useState } from 'react'
import { api } from '../api'
import TagInput from './TagInput'
import { toast } from './Toast'

export default function SelectionBar({ selected, visibleIds, onSelectAll, onClear, onTagged }) {
  const [tagging, setTagging] = useState(false)
  const [downloading, setDownloading] = useState(false)
  if (selected.size === 0) return null

  return (
    <div className="fade-up fixed inset-x-0 bottom-6 z-30 mx-auto flex w-fit max-w-[92vw] items-center gap-4 rounded-2xl border border-line bg-white px-5 py-3 shadow-pop">
      <span className="text-sm font-medium">
        <span className="text-pine">{selected.size}</span> selected
      </span>
      <div className="h-5 w-px bg-line" />
      <button onClick={onSelectAll} className="text-sm text-muted transition hover:text-ink">
        Select all in view ({visibleIds.length})
      </button>

      {tagging ? (
        <div className="w-48">
          <TagInput
            placeholder="Tag selected…"
            onAdd={async (tag) => {
              try {
                await api.bulkTag([...selected], [tag])
                onTagged()
              } catch { toast('Bulk tag failed', true) }
              setTagging(false)
            }}
          />
        </div>
      ) : (
        <button onClick={() => setTagging(true)} className="text-sm text-muted transition hover:text-ink">
          Tag
        </button>
      )}

      <button
        onClick={async () => {
          setDownloading(true)
          toast(`Zipping ${selected.size} files…`)
          await api.download([...selected], () => setDownloading(false))
        }}
        disabled={downloading}
        className="rounded-lg bg-pine px-4 py-1.5 text-sm font-medium text-white transition hover:bg-pine-deep disabled:opacity-60"
      >
        {downloading ? 'Preparing…' : 'Download ZIP'}
      </button>
      <button onClick={onClear} aria-label="Clear selection" className="text-muted transition hover:text-ink">×</button>
    </div>
  )
}
