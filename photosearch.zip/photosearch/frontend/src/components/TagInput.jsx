import { useEffect, useRef, useState } from 'react'
import { api } from '../api'

export default function TagInput({ onAdd, placeholder = 'Add a tag…' }) {
  const [value, setValue] = useState('')
  const [suggestions, setSuggestions] = useState([])
  const [hi, setHi] = useState(-1)
  const timer = useRef(null)

  // autocomplete from existing tags → fewer duplicates like “2005” vs “Year 2005”
  useEffect(() => {
    clearTimeout(timer.current)
    if (!value.trim()) return setSuggestions([])
    timer.current = setTimeout(() => {
      api.tagSuggest(value.trim()).then(setSuggestions).catch(() => {})
    }, 150)
    return () => clearTimeout(timer.current)
  }, [value])

  function commit(tag) {
    const t = tag.trim()
    if (!t) return
    onAdd(t)
    setValue('')
    setSuggestions([])
    setHi(-1)
  }

  return (
    <div className="relative">
      <input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown') setHi((h) => Math.min(h + 1, suggestions.length - 1))
          else if (e.key === 'ArrowUp') setHi((h) => Math.max(h - 1, -1))
          else if (e.key === 'Enter') commit(hi >= 0 ? suggestions[hi] : value)
          else if (e.key === 'Escape') setSuggestions([])
        }}
        placeholder={placeholder}
        className="w-full rounded-lg border border-line bg-white px-3 py-1.5 text-sm outline-none transition focus:border-pine focus:ring-4 focus:ring-pine/10"
      />
      {suggestions.length > 0 && (
        <ul className="absolute z-10 mt-1 w-full overflow-hidden rounded-lg border border-line bg-white shadow-pop">
          {suggestions.map((s, i) => (
            <li key={s}>
              <button
                onMouseDown={(e) => { e.preventDefault(); commit(s) }}
                className={`w-full px-3 py-1.5 text-left text-sm transition ${i === hi ? 'bg-pine-soft text-pine' : 'hover:bg-pine-soft'}`}
              >
                {s}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
