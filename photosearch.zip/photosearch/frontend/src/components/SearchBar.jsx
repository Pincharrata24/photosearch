import { useEffect, useRef } from 'react'

export default function SearchBar({ value, onChange, compact }) {
  const ref = useRef(null)

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === '/' && document.activeElement !== ref.current) {
        e.preventDefault()
        ref.current?.focus()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  return (
    <div className="relative">
      <svg
        className={`pointer-events-none absolute left-5 top-1/2 -translate-y-1/2 text-muted transition-all ${compact ? 'h-4 w-4' : 'h-5 w-5'}`}
        fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"
      >
        <path strokeLinecap="round" d="m21 21-4.3-4.3M17 10.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0Z" />
      </svg>
      <input
        ref={ref}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search photos — try “sports day”, “graduation 2019”, “kids painting”…"
        className={`w-full rounded-2xl border border-line bg-white pl-12 pr-12 text-ink shadow-hero outline-none transition-all placeholder:text-muted/70
          focus:border-pine focus:ring-4 focus:ring-pine/10
          ${compact ? 'py-3 text-base' : 'py-5 text-lg'}`}
        autoFocus
      />
      {value && (
        <button
          onClick={() => onChange('')}
          aria-label="Clear search"
          className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full p-1 text-muted transition hover:bg-pine-soft hover:text-ink"
        >
          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" d="M6 6l12 12M18 6 6 18" />
          </svg>
        </button>
      )}
    </div>
  )
}
