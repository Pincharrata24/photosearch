import { useEffect, useState } from 'react'

let push = () => {}
export function toast(msg, isError = false) { push({ msg, isError, id: Date.now() }) }

export function ToastHost() {
  const [items, setItems] = useState([])
  useEffect(() => {
    push = (t) => {
      setItems((xs) => [...xs, t])
      setTimeout(() => setItems((xs) => xs.filter((x) => x.id !== t.id)), 3200)
    }
    return () => { push = () => {} }
  }, [])
  return (
    <div className="pointer-events-none fixed bottom-24 left-1/2 z-50 flex -translate-x-1/2 flex-col items-center gap-2">
      {items.map((t) => (
        <div
          key={t.id}
          className={`fade-up rounded-full px-4 py-2 text-sm text-white shadow-pop ${t.isError ? 'bg-red-700' : 'bg-ink'}`}
        >
          {t.msg}
        </div>
      ))}
    </div>
  )
}
