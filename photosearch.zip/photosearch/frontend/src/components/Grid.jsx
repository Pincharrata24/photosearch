import { useEffect, useRef, useState } from 'react'

export default function Grid({ results, selected, onToggleSelect, onOpen, onFilterTag }) {
  if (results === null) {
    return (
      <div className="masonry">
        {Array.from({ length: 15 }).map((_, i) => (
          <div key={i} className="skeleton rounded-xl" style={{ height: 120 + ((i * 53) % 140) }} />
        ))}
      </div>
    )
  }

  if (results.length === 0) {
    return (
      <div className="py-24 text-center">
        <p className="font-display text-2xl text-ink">Nothing here yet</p>
        <p className="mt-2 text-sm text-muted">
          Try a different search, or add more folders to the index.
        </p>
      </div>
    )
  }

  return (
    <div className="masonry">
      {results.map((file, i) => (
        <Thumb
          key={file.id}
          file={file}
          isSelected={selected.has(file.id)}
          anySelected={selected.size > 0}
          onSelect={() => onToggleSelect(file.id)}
          onOpen={() => onOpen(i)}
          onFilterTag={onFilterTag}
        />
      ))}
    </div>
  )
}

function Thumb({ file, isSelected, anySelected, onSelect, onOpen, onFilterTag }) {
  const ref = useRef(null)
  const [visible, setVisible] = useState(false)
  const [loaded, setLoaded] = useState(false)

  // Lazy-load: only fetch the thumbnail once it scrolls near the viewport.
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect() } },
      { rootMargin: '400px' },
    )
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  return (
    <figure
      ref={ref}
      className={`group relative cursor-pointer overflow-hidden rounded-xl bg-white shadow-card outline-offset-2 transition
        ${isSelected ? 'outline outline-2 outline-pine' : 'hover:shadow-pop'}`}
      onClick={() => (anySelected ? onSelect() : onOpen())}
    >
      <div className="min-h-[90px]">
        {visible && file.thumbnail_link ? (
          <img
            src={file.thumbnail_link}
            alt={file.name}
            loading="lazy"
            onLoad={() => setLoaded(true)}
            className={`w-full transition-opacity duration-300 ${loaded ? 'opacity-100' : 'opacity-0'}`}
          />
        ) : (
          <div className="skeleton h-36 w-full" />
        )}
      </div>

      {file.is_video && (
        <span className="absolute right-2 top-2 rounded-md bg-ink/70 px-1.5 py-0.5 text-[10px] font-medium text-white">
          VIDEO
        </span>
      )}

      {/* selection checkbox */}
      <button
        onClick={(e) => { e.stopPropagation(); onSelect() }}
        aria-label={isSelected ? 'Deselect' : 'Select'}
        className={`absolute left-2 top-2 flex h-6 w-6 items-center justify-center rounded-full border transition
          ${isSelected
            ? 'border-pine bg-pine text-white opacity-100'
            : 'border-white/80 bg-ink/30 text-white opacity-0 backdrop-blur-sm group-hover:opacity-100'}`}
      >
        {isSelected ? '✓' : ''}
      </button>

      {/* hover info */}
      <figcaption className="pointer-events-none absolute inset-x-0 bottom-0 translate-y-2 bg-gradient-to-t from-ink/80 to-transparent p-3 pt-8 opacity-0 transition group-hover:translate-y-0 group-hover:opacity-100">
        <p className="truncate text-xs font-medium text-white">{file.name}</p>
        <p className="text-[11px] text-white/70">
          {file.created_time ? new Date(file.created_time).toLocaleDateString() : ''}
        </p>
        {file.tags?.length > 0 && (
          <div className="pointer-events-auto mt-1 flex flex-wrap gap-1">
            {file.tags.slice(0, 3).map((t) => (
              <button
                key={t}
                onClick={(e) => { e.stopPropagation(); onFilterTag(t) }}
                className="rounded-full bg-white/20 px-2 py-0.5 text-[10px] text-white backdrop-blur-sm transition hover:bg-pine"
              >
                {t}
              </button>
            ))}
          </div>
        )}
      </figcaption>
    </figure>
  )
}
