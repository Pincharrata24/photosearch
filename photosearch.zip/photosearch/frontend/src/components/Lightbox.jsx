import { useCallback, useEffect, useState } from 'react'
import { api } from '../api'
import TagInput from './TagInput'
import { toast } from './Toast'

export default function Lightbox({ results, index, onIndex, onClose, onPatch, onFilterTag }) {
  const file = results[index]

  const nav = useCallback((d) => {
    const next = index + d
    if (next >= 0 && next < results.length) onIndex(next)
  }, [index, results.length, onIndex])

  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === 'INPUT') return
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowRight') nav(1)
      if (e.key === 'ArrowLeft') nav(-1)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [nav, onClose])

  const bigThumb = file.thumbnail_link?.replace(/=s\d+$/, '') + '=s1600'

  return (
    <div className="fade-up fixed inset-0 z-40 flex bg-ink/85 backdrop-blur-sm" onClick={onClose}>
      {/* image stage */}
      <div className="relative flex flex-1 items-center justify-center p-8" onClick={(e) => e.stopPropagation()}>
        <NavBtn dir={-1} onClick={() => nav(-1)} disabled={index === 0} />
        <img src={bigThumb} alt={file.name} className="max-h-full max-w-full rounded-lg shadow-pop" />
        <NavBtn dir={1} onClick={() => nav(1)} disabled={index === results.length - 1} />
      </div>

      {/* metadata panel */}
      <aside
        className="flex w-96 shrink-0 flex-col gap-5 overflow-y-auto bg-paper p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3">
          <RenameField file={file} onPatch={onPatch} />
          <button onClick={onClose} aria-label="Close" className="rounded-full p-1.5 text-muted transition hover:bg-pine-soft hover:text-ink">
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" d="M6 6l12 12M18 6 6 18" /></svg>
          </button>
        </div>

        <dl className="space-y-2 text-sm">
          <Row label="Folder" value={file.folder_path} />
          <Row label="Created" value={file.created_time && new Date(file.created_time).toLocaleString()} />
          <Row label="Size" value={file.size ? `${(file.size / 1e6).toFixed(1)} MB` : null} />
          <Row label="Type" value={file.mime_type} />
        </dl>

        <div>
          <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Tags</p>
          <div className="mb-2 flex flex-wrap gap-1.5">
            {(file.tags || []).map((t) => (
              <span key={t} className="group flex items-center gap-1 rounded-full bg-pine-soft px-2.5 py-1 text-xs text-pine">
                <button onClick={() => onFilterTag(t)} className="hover:underline">{t}</button>
                <button
                  aria-label={`Remove tag ${t}`}
                  onClick={async () => {
                    onPatch(file.id, { tags: file.tags.filter((x) => x !== t) }) // optimistic
                    try { await api.removeTag(file.id, t) } catch { toast('Could not remove tag', true) }
                  }}
                  className="opacity-50 transition hover:opacity-100"
                >×</button>
              </span>
            ))}
          </div>
          <TagInput
            onAdd={async (tag) => {
              onPatch(file.id, { tags: [...new Set([...(file.tags || []), tag])] }) // optimistic
              try { await api.addTags(file.id, [tag]) } catch { toast('Could not add tag', true) }
            }}
          />
        </div>

        <div className="mt-auto flex gap-2 border-t border-line pt-4">
          <a
            href={file.web_view_link} target="_blank" rel="noreferrer"
            className="flex-1 rounded-lg border border-line bg-white py-2 text-center text-sm transition hover:border-pine hover:text-pine"
          >
            Open in Drive
          </a>
          <button
            onClick={() => { api.download([file.id]); toast('Preparing download…') }}
            className="flex-1 rounded-lg bg-pine py-2 text-sm font-medium text-white transition hover:bg-pine-deep"
          >
            Download
          </button>
        </div>
      </aside>
    </div>
  )
}

function RenameField({ file, onPatch }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(file.name)

  useEffect(() => { setDraft(file.name); setEditing(false) }, [file.id, file.name])

  async function save() {
    const name = draft.trim()
    setEditing(false)
    if (!name || name === file.name) return setDraft(file.name)
    const prev = file.name
    onPatch(file.id, { name }) // optimistic: show instantly, sync in background
    try {
      await api.rename(file.id, name)
      toast('Renamed in Drive')
    } catch {
      onPatch(file.id, { name: prev })
      toast('Rename failed', true)
    }
  }

  return editing ? (
    <input
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={save}
      onKeyDown={(e) => { if (e.key === 'Enter') save(); if (e.key === 'Escape') { setDraft(file.name); setEditing(false) } }}
      autoFocus
      className="w-full rounded-lg border border-pine bg-white px-2 py-1 font-medium outline-none ring-4 ring-pine/10"
    />
  ) : (
    <button
      onClick={() => setEditing(true)}
      title="Click to rename"
      className="break-all rounded-lg px-2 py-1 text-left font-medium transition hover:bg-pine-soft"
    >
      {file.name}
    </button>
  )
}

function Row({ label, value }) {
  if (!value) return null
  return (
    <div className="flex gap-3">
      <dt className="w-16 shrink-0 text-xs font-medium uppercase tracking-wide text-muted">{label}</dt>
      <dd className="break-all text-ink">{value}</dd>
    </div>
  )
}

function NavBtn({ dir, onClick, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      aria-label={dir === 1 ? 'Next' : 'Previous'}
      className={`absolute ${dir === 1 ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white backdrop-blur-sm transition hover:bg-white/25 disabled:opacity-20`}
    >
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" d={dir === 1 ? 'm9 5 7 7-7 7' : 'm15 19-7-7 7-7'} />
      </svg>
    </button>
  )
}
