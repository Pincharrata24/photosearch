import { useEffect, useState } from 'react'
import { api } from '../api'
import { toast } from './Toast'

export default function IndexingPanel({ status, onClose }) {
  const [browsePath, setBrowsePath] = useState([]) // [{id, name}]
  const [folders, setFolders] = useState(null)
  const [picked, setPicked] = useState([])

  const parent = browsePath[browsePath.length - 1]?.id

  useEffect(() => {
    setFolders(null)
    api.browseFolders(parent).then(setFolders).catch(() => setFolders([]))
  }, [parent])

  const pct = status && status.embeddable > 0
    ? Math.round((status.embedded / status.embeddable) * 100) : 0

  return (
    <div className="fixed inset-0 z-40 flex items-start justify-center bg-ink/40 p-6 pt-[10vh] backdrop-blur-sm" onClick={onClose}>
      <div
        className="fade-up flex max-h-[80vh] w-full max-w-xl flex-col gap-6 overflow-y-auto rounded-2xl bg-paper p-6 shadow-pop"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg">Indexing</h2>
          <button onClick={onClose} aria-label="Close" className="rounded-full p-1.5 text-muted hover:bg-pine-soft hover:text-ink">
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" d="M6 6l12 12M18 6 6 18" /></svg>
          </button>
        </div>

        {/* overall progress */}
        {status && (
          <div>
            <div className="mb-1 flex justify-between text-sm">
              <span className="text-muted">Visual search ready</span>
              <span className="font-medium">
                {status.embedded.toLocaleString()} / {status.embeddable.toLocaleString()} photos
              </span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-line">
              <div className="h-full rounded-full bg-pine transition-all duration-700" style={{ width: `${pct}%` }} />
            </div>
            <p className="mt-1.5 text-xs text-muted">
              {status.total_files.toLocaleString()} files indexed in total. Embeddings are computed in the
              background from small thumbnails and cached permanently.
            </p>
          </div>
        )}

        {/* indexed folders */}
        <div>
          <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Indexed folders</p>
          {status?.folders.length === 0 && (
            <p className="text-sm text-muted">No folders yet. Pick one below to start small — you can add more anytime.</p>
          )}
          <ul className="space-y-2">
            {status?.folders.map((f) => (
              <li key={f.id} className="flex items-center justify-between rounded-lg border border-line bg-white px-3 py-2 text-sm">
                <span className="truncate font-medium">{f.name}</span>
                <span className="flex items-center gap-2 text-xs text-muted">
                  {f.indexed_count.toLocaleString()} files
                  <StatusDot status={f.status} />
                  {f.status}
                </span>
              </li>
            ))}
          </ul>
        </div>

        {/* folder browser */}
        <div>
          <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted">Add folders</p>
          <nav className="mb-2 flex flex-wrap items-center gap-1 text-sm text-muted">
            <button onClick={() => setBrowsePath([])} className="hover:text-pine">My Drive</button>
            {browsePath.map((b, i) => (
              <span key={b.id} className="flex items-center gap-1">
                <span>/</span>
                <button onClick={() => setBrowsePath(browsePath.slice(0, i + 1))} className="hover:text-pine">{b.name}</button>
              </span>
            ))}
          </nav>
          <ul className="max-h-52 space-y-1 overflow-y-auto rounded-lg border border-line bg-white p-2">
            {folders === null && <li className="skeleton h-8 rounded-md" />}
            {folders?.length === 0 && <li className="px-2 py-1 text-sm text-muted">No subfolders here.</li>}
            {folders?.map((f) => {
              const isPicked = picked.some((p) => p.id === f.id)
              return (
                <li key={f.id} className="flex items-center justify-between rounded-md px-2 py-1 text-sm hover:bg-pine-soft">
                  <button onClick={() => setBrowsePath([...browsePath, f])} className="flex-1 truncate text-left">
                    📁 {f.name}
                  </button>
                  <button
                    onClick={() => setPicked(isPicked ? picked.filter((p) => p.id !== f.id) : [...picked, f])}
                    className={`rounded-full px-2.5 py-0.5 text-xs transition ${isPicked ? 'bg-pine text-white' : 'border border-line text-muted hover:border-pine hover:text-pine'}`}
                  >
                    {isPicked ? 'Picked' : 'Pick'}
                  </button>
                </li>
              )
            })}
          </ul>
          {picked.length > 0 && (
            <button
              onClick={async () => {
                try {
                  await api.addFolders(picked.map(({ id, name }) => ({ id, name })))
                  toast(`Indexing ${picked.length} folder${picked.length > 1 ? 's' : ''} started`)
                  setPicked([])
                  onClose()
                } catch { toast('Could not start indexing', true) }
              }}
              className="mt-3 w-full rounded-lg bg-pine py-2 text-sm font-medium text-white transition hover:bg-pine-deep"
            >
              Start indexing {picked.length} folder{picked.length > 1 ? 's' : ''}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

function StatusDot({ status }) {
  const color = { indexing: 'bg-pine animate-pulse', done: 'bg-pine', queued: 'bg-muted', error: 'bg-red-600' }[status] || 'bg-muted'
  return <span className={`inline-block h-1.5 w-1.5 rounded-full ${color}`} />
}
