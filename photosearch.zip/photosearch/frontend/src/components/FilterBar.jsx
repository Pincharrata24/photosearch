import { useState } from 'react'

export default function FilterBar({ filters, onChange }) {
  const [open, setOpen] = useState(false)
  const active = Object.entries(filters).filter(([, v]) => v)

  const set = (k, v) => onChange({ ...filters, [k]: v || undefined })

  return (
    <div className="mt-3">
      <div className="flex flex-wrap items-center justify-center gap-2">
        <button
          onClick={() => setOpen(!open)}
          className={`rounded-full border px-3 py-1 text-xs transition ${open ? 'border-pine bg-pine-soft text-pine' : 'border-line bg-white text-muted hover:text-ink'}`}
        >
          Filters {active.length > 0 && `· ${active.length}`}
        </button>
        {active.map(([k, v]) => (
          <button
            key={k}
            onClick={() => set(k, undefined)}
            className="group flex items-center gap-1.5 rounded-full bg-pine-soft px-3 py-1 text-xs text-pine transition hover:bg-pine hover:text-white"
          >
            {label(k, v)}
            <span aria-hidden>×</span>
          </button>
        ))}
      </div>

      {open && (
        <div className="fade-up mx-auto mt-3 flex max-w-xl flex-wrap items-center justify-center gap-x-5 gap-y-3 rounded-xl border border-line bg-white p-4 text-sm shadow-card">
          <Field label="Type">
            <Select value={filters.type} onChange={(v) => set('type', v)}
              options={[['', 'All'], ['photo', 'Photos'], ['video', 'Videos']]} />
          </Field>
          <Field label="Tags">
            <Select value={filters.tagged} onChange={(v) => set('tagged', v)}
              options={[['', 'All'], ['tagged', 'Tagged'], ['untagged', 'Untagged']]} />
          </Field>
          <Field label="From">
            <input type="date" value={filters.date_from || ''} onChange={(e) => set('date_from', e.target.value)} className={inputCls} />
          </Field>
          <Field label="To">
            <input type="date" value={filters.date_to || ''} onChange={(e) => set('date_to', e.target.value)} className={inputCls} />
          </Field>
          <Field label="Folder">
            <input value={filters.folder || ''} onChange={(e) => set('folder', e.target.value)}
              placeholder="e.g. 2019" className={inputCls + ' w-28'} />
          </Field>
        </div>
      )}
    </div>
  )
}

const inputCls = 'rounded-lg border border-line bg-paper px-2 py-1 text-sm outline-none focus:border-pine'

function Field({ label, children }) {
  return (
    <label className="flex items-center gap-2 text-muted">
      <span className="text-xs font-medium uppercase tracking-wide">{label}</span>
      {children}
    </label>
  )
}

function Select({ value, onChange, options }) {
  return (
    <select value={value || ''} onChange={(e) => onChange(e.target.value)} className={inputCls}>
      {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
    </select>
  )
}

function label(k, v) {
  const names = { type: '', tagged: '', tag: 'tag: ', folder: 'folder: ', date_from: 'from ', date_to: 'to ' }
  return `${names[k] ?? ''}${v}`
}
