import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { api } from './api'
import FilterBar from './components/FilterBar'
import Grid from './components/Grid'
import IndexingPanel from './components/IndexingPanel'
import Lightbox from './components/Lightbox'
import SearchBar from './components/SearchBar'
import SelectionBar from './components/SelectionBar'
import { ToastHost, toast } from './components/Toast'

export default function App() {
  const [auth, setAuth] = useState(null)
  const [query, setQuery] = useState('')
  const [filters, setFilters] = useState({})
  const [results, setResults] = useState(null) // null = loading
  const [selected, setSelected] = useState(new Set())
  const [lightboxIdx, setLightboxIdx] = useState(null)
  const [showIndexing, setShowIndexing] = useState(false)
  const [status, setStatus] = useState(null)
  const reqId = useRef(0)

  const hasQuery = query.trim().length > 0 || Object.values(filters).some(Boolean)

  useEffect(() => {
    api.authStatus().then(setAuth).catch(() => setAuth({ connected: false }))
    refreshStatus()
    const t = setInterval(refreshStatus, 15000)
    return () => clearInterval(t)
  }, [])

  function refreshStatus() {
    api.indexStatus().then(setStatus).catch(() => {})
  }

  const runSearch = useCallback((q, f) => {
    const id = ++reqId.current
    setResults(null)
    const call = q.trim() || Object.values(f).some(Boolean)
      ? api.search({ q: q.trim(), ...f })
      : api.recent()
    call.then((rows) => { if (id === reqId.current) setResults(rows) })
        .catch(() => { if (id === reqId.current) setResults([]) })
  }, [])

  // search-as-you-type with debounce
  useEffect(() => {
    const t = setTimeout(() => runSearch(query, filters), 250)
    return () => clearTimeout(t)
  }, [query, filters, runSearch])

  const patchFile = useCallback((id, patch) => {
    setResults((rs) => rs?.map((r) => (r.id === id ? { ...r, ...patch } : r)))
  }, [])

  const toggleSelect = useCallback((id) => {
    setSelected((s) => {
      const n = new Set(s)
      n.has(id) ? n.delete(id) : n.add(id)
      return n
    })
  }, [])

  const visibleIds = useMemo(() => (results || []).map((r) => r.id), [results])

  if (auth && !auth.connected) return <ConnectScreen />

  return (
    <div className="min-h-screen pb-32">
      <header className={`transition-all ${hasQuery ? 'pt-6' : 'pt-[18vh]'}`}>
        <div className="mx-auto max-w-3xl px-6">
          <div className="mb-6 flex items-center justify-between">
            <h1 className="font-display text-xl text-ink">
              Photo<span className="text-pine">Search</span>
            </h1>
            <button
              onClick={() => setShowIndexing(true)}
              className="rounded-full border border-line bg-white px-3.5 py-1.5 text-sm text-muted transition hover:border-pine hover:text-pine"
            >
              Indexing
              {status && status.folders.some((f) => f.status === 'indexing') && (
                <span className="ml-2 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-pine align-middle" />
              )}
            </button>
          </div>

          <SearchBar value={query} onChange={setQuery} compact={hasQuery} />

          {!hasQuery && status && (
            <p className="mt-4 text-center font-display italic text-muted">
              Searching {status.total_files.toLocaleString()} photos and videos
            </p>
          )}

          <FilterBar filters={filters} onChange={setFilters} />
        </div>
      </header>

      <main className="mx-auto mt-8 max-w-[1600px] px-6">
        {!hasQuery && results?.length > 0 && (
          <p className="mb-4 text-xs font-medium uppercase tracking-wider text-muted">
            Recently added
          </p>
        )}
        <Grid
          results={results}
          selected={selected}
          onToggleSelect={toggleSelect}
          onOpen={setLightboxIdx}
          onFilterTag={(tag) => setFilters((f) => ({ ...f, tag }))}
        />
      </main>

      <SelectionBar
        selected={selected}
        visibleIds={visibleIds}
        onSelectAll={() => setSelected(new Set(visibleIds))}
        onClear={() => setSelected(new Set())}
        onTagged={() => { runSearch(query, filters); toast('Tags applied') }}
      />

      {lightboxIdx != null && results?.[lightboxIdx] && (
        <Lightbox
          results={results}
          index={lightboxIdx}
          onIndex={setLightboxIdx}
          onClose={() => setLightboxIdx(null)}
          onPatch={patchFile}
          onFilterTag={(tag) => { setFilters((f) => ({ ...f, tag })); setLightboxIdx(null) }}
        />
      )}

      {showIndexing && (
        <IndexingPanel status={status} onClose={() => { setShowIndexing(false); refreshStatus() }} />
      )}

      <ToastHost />
    </div>
  )
}

function ConnectScreen() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <h1 className="font-display text-4xl">
        Photo<span className="text-pine">Search</span>
      </h1>
      <p className="mt-3 max-w-sm text-muted">
        Connect the school's Google Drive to start indexing and searching your photo archive.
      </p>
      <a
        href="/api/auth/login"
        className="mt-8 rounded-full bg-pine px-6 py-3 font-medium text-white shadow-hero transition hover:bg-pine-deep"
      >
        Connect Google Drive
      </a>
    </div>
  )
}
