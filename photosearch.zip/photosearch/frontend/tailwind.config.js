/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#FAFAF7',
        ink: '#1C1C19',
        muted: '#75736A',
        line: '#E9E7E0',
        pine: { DEFAULT: '#2E5D50', soft: '#EEF3F1', deep: '#234A40' },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Fraunces', 'Georgia', 'serif'],
      },
      boxShadow: {
        hero: '0 1px 2px rgba(28,28,25,.05), 0 8px 32px rgba(46,93,80,.10)',
        card: '0 1px 3px rgba(28,28,25,.08)',
        pop: '0 8px 40px rgba(28,28,25,.18)',
      },
    },
  },
  plugins: [],
}
